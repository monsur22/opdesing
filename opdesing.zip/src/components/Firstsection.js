import React from 'react'
// import "./Firstsection.css";

const Firstsection = () => {
    return (
        <>
    <section class="header">
        <div class="header-title">通気性と速乾性で <br/>
            どんなシーンでもサラサラ
        </div>
        <div class="header-footer">
            <b>ONEPROOF®︎</b> TECH
        </div>

    </section>
    <section class="header-buttom">

    </section>
    </>
    )
}

export default Firstsection